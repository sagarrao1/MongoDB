package com.user.gridfs;

import java.io.FileOutputStream;
import java.io.IOException;

import org.bson.types.ObjectId;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.model.GridFSDownloadOptions;

public class DownloadFromBuckets {
	public static void main (String args[]) {
		MongoClient mongoClient = MongoClients.create();
		System.out.println("Connected to Server");
		
		MongoDatabase myDatabase = mongoClient.getDatabase("test");
		System.out.println("Connected to test Database");
		
		// Create a gridFSBucket using the default bucket name "fs"
				GridFSBucket gridFSBucket = GridFSBuckets.create(myDatabase);
				System.out.println("Created GridFS Bucket");
				try {
				    FileOutputStream streamToDownloadTo = new FileOutputStream("/Downloads/Avengers - 4 - ENDGAME 2019 Official Trailer.mkv");
				    GridFSDownloadOptions downloadOptions = new GridFSDownloadOptions().revision(0);
				    gridFSBucket.downloadToStream("avengers4-trailer", streamToDownloadTo, downloadOptions);
				    streamToDownloadTo.close();
				    System.out.println("File Downloaded Successfully");
				} catch (IOException e) {
				   // handle exception
			System.out.println("File Not Found");
		}
	}

}
