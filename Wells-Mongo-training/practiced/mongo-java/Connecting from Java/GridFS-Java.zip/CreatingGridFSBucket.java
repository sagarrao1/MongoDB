package com.user.gridfs;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.*;


public class CreatingGridFSBucket {
	public static void main (String args[]) {
		MongoClient mongoClient = MongoClients.create();
		System.out.println("Connected to Server");
		
		MongoDatabase myDatabase = mongoClient.getDatabase("test");
		System.out.println("Connected to test Database");

		// Create a gridFSBucket using the default bucket name "fs"
		GridFSBucket gridFSBucket = GridFSBuckets.create(myDatabase);
		System.out.println("Created GridFS Bucket");
		
		// Create a gridFSBucket with a custom bucket name "files"
		GridFSBucket gridFSFilesBucket = GridFSBuckets.create(myDatabase, "files");
		System.out.println("Created GridFS Bucket files");
		
	}

}
