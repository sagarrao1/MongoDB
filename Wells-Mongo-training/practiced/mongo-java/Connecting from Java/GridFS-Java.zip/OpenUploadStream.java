package com.user.gridfs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSUploadStream;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class OpenUploadStream {
	public static void main (String args[]) {
		MongoClient mongoClient = MongoClients.create();
		System.out.println("Connected to Server");
		
		MongoDatabase myDatabase = mongoClient.getDatabase("test");
		System.out.println("Connected to test Database");
		
		// Create a gridFSBucket with a custom bucket name "files"
		GridFSBucket gridFSFilesBucket = GridFSBuckets.create(myDatabase, "files");
		
		// Open Upload stream

		try {
		    GridFSUploadOptions options = new GridFSUploadOptions()
		                       .chunkSizeBytes(358400)
		                       .metadata(new Document("type", "presentation"));

		    GridFSUploadStream uploadStream = gridFSFilesBucket.openUploadStream("mongodb-tutorial-2", options);
		    byte[] data = Files.readAllBytes(new File("/tmp/MongoDB-manual-master.pdf").toPath());

		    uploadStream.write(data);
		    uploadStream.close();
		    System.out.println("The fileId of the uploaded file is: " + uploadStream.getObjectId().toHexString());

		} catch(IOException e){
		    // handle exception
			System.out.println("File Not Found");
		}
	}

}
