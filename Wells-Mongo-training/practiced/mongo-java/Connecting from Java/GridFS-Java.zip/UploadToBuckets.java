package com.user.gridfs;

import com.mongodb.Block;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.*;
import com.mongodb.client.gridfs.model.*;
import org.bson.Document;
import org.bson.types.ObjectId;
import java.io.*;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import static com.mongodb.client.model.Filters.eq;

public class UploadToBuckets {
	public static void main (String args[]) {
		MongoClient mongoClient = MongoClients.create();
		System.out.println("Connected to Server");
		
		MongoDatabase myDatabase = mongoClient.getDatabase("test");
		System.out.println("Connected to test Database");
		
		// Create a gridFSBucket using the default bucket name "fs"
				GridFSBucket gridFSBucket = GridFSBuckets.create(myDatabase);
				System.out.println("Created GridFS Bucket");
		
		// Get the input stream

		try {
		    InputStream streamToUploadFrom = new FileInputStream(new File("/Avengers - 4 - ENDGAME 2019 Official Trailer.mkv"));
		    // Create some custom options
		    GridFSUploadOptions options = new GridFSUploadOptions()
		                                        .chunkSizeBytes(358400)
		                                        .metadata(new Document("type", "presentation"));

		    ObjectId fileId = gridFSBucket.uploadFromStream("avengers4-trailer", streamToUploadFrom, options);
		    System.out.println("File uploaded Successfully");
		} catch (FileNotFoundException e){
		   // handle exception
			System.out.println("File not Found");
		}
	}

}
